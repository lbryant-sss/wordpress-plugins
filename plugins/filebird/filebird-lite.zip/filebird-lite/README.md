# Change Log

All notable changes to this project will be documented in this file.

## Unreleased

## Released

## 4.7.2

- Fix can't set default Uncategorized in folder load
- Fix append right folder
- Fix update database make duplicate folders when "folder each user mode" enabled
- Improve Tooltip
- Import UI
- Optimize Filebird Zip Size
- Added: Upload multiple images in multiple folders when upload processing
- Improve Auto Upgrade

## 4.7

- Added: New Resize bar
- Improved: Performance
- Improved: Optimize code
- Improved: UI
- Improved: Text
- Supported: PHP 8 and greater
- Supported: Tatsu Builder
- Fixed: Counter in WPML
- Fixed: Tooltip bugs
- Fixed: Can't set "Uncategorized" default folder load
- Fixed: Reorder on Edit gallery
- Fixed: Small bugs

## 4.6

- Improve import folders
- Added import folder from HappyFiles plugin

## 4.5

- Fix counter folder bug when moving images in folder each user mode
- Fix conflict with Picu plugin
- Fix conflict with TutorLMS plugin

## 4.4.1

- Sync Images in Folder for FileBird Gallery (Gutenberg Block)
- Fix Gutenberg load all images when Folder Each Person Mode enable

## 4.4

- Add download folder feature
- Fix duplicate folder when import
- Improve perfomence
- Fix folder scroll

## 4.3.2

- Fix draggable for tablet
- Fix Edit Gallery
- Fix Over The Max Number Of attachmentID
- Fix FileBird Gallery selector in Guntenberg
- Disable draggable attachment in Mobile

## 4.3.1

- Fix modal conflict from Yoast SEO and Woocommerce
- Support Document Gallery

## 4.3

- Fix upload new image can't insert to the post in modal
- Fix prevent reload attachment when sort folders

## 4.2.1

- Fix Missing Folder Container
- Change alert text
- Add ESC key to exist bulk select mode
- Fix security
- Fix SQL

## 4.2

- Fix ACF warning
- Fix conflict with WPML rest API
- Fix FileBird Tree overflow for The Grid plugin
- Compatible Oxygen Builder
- Prevent warning when upload folder contain desktop.ini or .DS_Store

## 4.1

- Support ACF
- Improve first folder admin notice
- Fix some bugs in folder container
- Remove folder selector when no items available modal popup
- Add feature set default folder to open

## 4.0.6

### Changed

- Fixed: Can't create table 'fbv_attachment_folder'
- Fixed Screen Option hidden in Media Upload
- Compatible with Cornerstone Page Builder Plugin (From X Theme)
- Fixed: Browser security issue with Microsoft Edge, Firefox
- Fixed: Conflict jQuery-UI with ACF plugin

# README

How to design your files with free or pro version:
/_ free/check_new_folder.txt _/
/_ pro/check_new_folder.txt _/

```bash
How to build ?
$ cd release
$ chmod +x run
$ ./run pro
Or
$ ./run free
```

# SQL Process

## WPML

Select the attachments were translated by WPML but not inside folder.

```sql
SELECT *, GROUP_CONCAT(icl.element_id) as test, GROUP_CONCAT(IF(fbv.folder_id is null, icl.element_id, NULL)) as infolder, COUNT(icl.element_id) as counter FROM `wp_icl_translations` icl
LEFT JOIN `wp_fbv_attachment_folder` fbv
ON fbv.attachment_id = icl.element_id
WHERE (icl.element_type = 'post_attachment' )
GROUP BY icl.trid
HAVING (COUNT(icl.element_id) > COUNT(fbv.folder_id) AND COUNT(fbv.folder_id) > 0 )
```
